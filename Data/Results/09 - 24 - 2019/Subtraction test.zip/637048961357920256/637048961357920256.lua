--   STEP 0: Get application
   VSes_Application = cf.GetApplication()
--

-- STEP 1: Make a new project
   VAnt_Project    = VSes_Application:NewProject()
   VAnt_Geometry   = VAnt_Project.Geometry
--

-- STEP 2: Set project unit of measurement
   VAnt_Project.ModelUnit  = cf.Enums.ModelUnitEnum.Millimeters
--

-- STEP 3: Create new rectangular surface
   VTmp_Corner = cf.Point(0.0, 0.0, 0.0)
   VAnt_Rectangle_1 = VAnt_Geometry:AddRectangle(VTmp_Corner, 100.0, 100.0)
   VAnt_Rectangle_1.Label = "1"
--

-- STEP 4: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(1.0, 1.0, 0.0)
   VTmp_Points[2] = cf.Point(26.0, 1.0, 0.0)
   VTmp_Points[3] = cf.Point(1.0, 26.0, 0.0)
   VAnt_Polygon_2 = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_2.Label = "2"
--

-- STEP 5: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(1.0, 26.0, 0.0)
   VTmp_Points[2] = cf.Point(1.0, 51.0, 0.0)
   VTmp_Points[3] = cf.Point(26.0, 51.0, 0.0)
   VAnt_Polygon_a = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_a.Label = "a"
--

-- STEP 6: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(26.0, 51.0, 0.0)
   VTmp_Points[2] = cf.Point(51.0, 51.0, 0.0)
   VTmp_Points[3] = cf.Point(51.0, 26.0, 0.0)
   VAnt_Polygon_b = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_b.Label = "b"
--

-- STEP 7: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(51.0, 26.0, 0.0)
   VTmp_Points[2] = cf.Point(26.0, 1.0, 0.0)
   VTmp_Points[3] = cf.Point(51.0, 26.0, 0.0)
   VAnt_Polygon_c = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_c.Label = "c"
--

-- STEP 8: Create new subtraction
   VTmp_Subs = {}
   VTmp_Subs[1] = VAnt_Polygon_2
   VTmp_Subs[2] = VAnt_Polygon_a
   VTmp_Subs[3] = VAnt_Polygon_b
   VTmp_Subs[4] = VAnt_Polygon_c
   VAnt_Subrtaction_3 = VAnt_Geometry:Subtract(VAnt_Rectangle_1, VTmp_Subs)
   VAnt_Subrtaction_3.Label = "3"
--

-- STEP 9: Create new rectangular surface
   VTmp_Corner = cf.Point(0.0, 0.0, 1.6)
   VAnt_Rectangle_4 = VAnt_Geometry:AddRectangle(VTmp_Corner, 100.0, 100.0)
   VAnt_Rectangle_4.Label = "4"
--

-- STEP 10: Save project
   VSes_Application:SaveAs("C:/Users/project/0. My Work/1. Repositories/0. Unfriendly Train/Code/Templates/Tests/Lua/637048961357920256_test/subtraction test.cfx")
--

-- STEP 11: Close project
   VSes_Application:CloseAllWindows()
--

-- STEP ??: Close file
   VSes_Application:CloseAllWindows()
   VSes_Application:Close()
--
