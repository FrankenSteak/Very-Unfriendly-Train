--   STEP 0: Get application
   VSes_Application = cf.GetApplication()
--

-- STEP 1: Make a new project
   VAnt_Project    = VSes_Application:NewProject()
   VAnt_Geometry   = VAnt_Project.Geometry
--

-- STEP 2: Set project unit of measurement
   VAnt_Project.ModelUnit  = cf.Enums.ModelUnitEnum.Millimetres
--

-- STEP 3: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(82.28759, 53.578230000000005, 1.6)
   VTmp_Points[2] = cf.Point(82.28759, 55.178230000000006, 1.6)
   VTmp_Points[3] = cf.Point(88.68759, 55.178230000000006, 1.6)
   VTmp_Points[4] = cf.Point(88.68759, 53.578230000000005, 1.6)
   VAnt_Polygon_Feed_Top = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_Feed_Top.Label = "Feed_Top"
--

-- STEP 4: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(88.68759, 55.178230000000006, 1.6)
   VTmp_Points[2] = cf.Point(88.68759, 55.178230000000006, 0.8)
   VTmp_Points[3] = cf.Point(88.68759, 53.578230000000005, 0.8)
   VTmp_Points[4] = cf.Point(88.68759, 53.578230000000005, 1.6)
   VAnt_Polygon_Feed_Pos = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_Feed_Pos.Label = "Feed_Pos"
--

-- STEP 5: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(88.68759, 55.178230000000006, 0.0)
   VTmp_Points[2] = cf.Point(88.68759, 55.178230000000006, 0.8)
   VTmp_Points[3] = cf.Point(88.68759, 53.578230000000005, 0.8)
   VTmp_Points[4] = cf.Point(88.68759, 53.578230000000005, 0.0)
   VAnt_Polygon_Feed_Neg = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_Feed_Neg.Label = "Feed_Neg"
--

-- STEP 6: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(88.68759, 53.578230000000005, 0.0)
   VTmp_Points[2] = cf.Point(88.68759, 55.178230000000006, 0.0)
   VTmp_Points[3] = cf.Point(87.08759, 55.178230000000006, 0.0)
   VTmp_Points[4] = cf.Point(87.08759, 53.578230000000005, 0.0)
   VAnt_Polygon_Feed_Bot = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_Feed_Bot.Label = "Feed_Bot"
--

-- STEP 7: Create new rectangular surface
   VTmp_Corner = cf.Point(0.0, 0.0, 0.0)
   VAnt_Rectangle_GP = VAnt_Geometry:AddRectangle(VTmp_Corner, 87.08759, 108.75646)
   VAnt_Rectangle_GP.Label = "GP"
--

-- STEP 8: Creating medium
   VAnt_Medium_FR4 = VAnt_Project.Media:AddDielectric()
   VAnt_Medium_FR4.Label = "FR4"
   VAnt_Medium_FR4.DielectricModelling.RelativePermittivity = 4.4
   VAnt_Medium_FR4.DielectricModelling.LossTangent = 0.02
--

-- STEP 9: Create new solid.cuboid
   VTmp_Corner = cf.Point(0.0, 0.0, 0.0)
   VAnt_Cuboid_Substrate = VAnt_Geometry:AddCuboid(VTmp_Corner, 87.08759, 108.75646, 1.6)
   VAnt_Cuboid_Substrate.Label = "Substrate"
--

-- STEP 10: Set solid medium
   VAnt_Cuboid_Substrate.Regions:Item(1).Medium = VAnt_Project.Media:Item("FR4")
--

-- STEP 11: Create new rectangular surface
   VTmp_Corner = cf.Point(4.8, 4.8, 1.6)
   VAnt_Rectangle_RP = VAnt_Geometry:AddRectangle(VTmp_Corner, 77.48759, 99.15646)
   VAnt_Rectangle_RP.Label = "RP"
--

-- STEP 12: Create new union
   VTmp_Parts = {}
   VTmp_Parts[1] = VAnt_Rectangle_GP
   VTmp_Parts[2] = VAnt_Rectangle_RP
   VTmp_Parts[3] = VAnt_Cuboid_Substrate
   VTmp_Parts[4] = VAnt_Polygon_Feed_Top
   VTmp_Parts[5] = VAnt_Polygon_Feed_Pos
   VTmp_Parts[6] = VAnt_Polygon_Feed_Neg
   VTmp_Parts[7] = VAnt_Polygon_Feed_Bot
   VAnt_Union_Onion = VAnt_Geometry:Union(VTmp_Parts)
   VAnt_Union_Onion.Label = "Onion"
--

-- STEP 13: Changing face medium
   VAnt_Union_Onion.Faces:Item("Face13").Medium = VAnt_Project.Media:Item("Perfect electric conductor")
--

-- STEP 14: Changing face medium
   VAnt_Union_Onion.Faces:Item("Face14").Medium = VAnt_Project.Media:Item("Perfect electric conductor")
--

-- STEP 15: Changing face medium
   VAnt_Union_Onion.Faces:Item("Face15").Medium = VAnt_Project.Media:Item("Perfect electric conductor")
--

-- STEP 16: Create new edge port
   VTmp_Pos = {}
   VTmp_Neg = {}
   VTmp_Pos[1] = VAnt_Union_Onion.Faces:Item("Face2")
   VTmp_Neg[1] = VAnt_Union_Onion.Faces:Item("Face3")
   VAnt_EPort_SourcePort = VAnt_Project.Ports:AddEdgePort(VTmp_Pos, VTmp_Neg)
   VAnt_EPort_SourcePort.Label = "SourcePort"
--

-- STEP 17: Get config file
   VAnt_Config = VAnt_Project.SolutionConfigurations[1]
--

-- STEP 18: Create new voltage source
   VAnt_VSource_VoltageSource = VAnt_Config.Sources:AddVoltageSource(VAnt_EPort_SourcePort)
   VAnt_VSource_VoltageSource.Impedance = 50.0
   VAnt_VSource_VoltageSource.Magnitude = 1.0
   VAnt_VSource_VoltageSource.Phase = 0.0
   VAnt_VSource_VoltageSource.Label = "VoltageSource"
--

-- STEP 19: Set frequency range
   VAnt_tmp = VAnt_Config.Frequency:GetProperties()
   VAnt_tmp.Start  = 880000000.0
   VAnt_tmp.End    = 960000000.0
   VAnt_tmp.RangeType  = cf.Enums.FrequencyRangeTypeEnum.LinearSpacedDiscrete
   VAnt_tmp.NumberOfDiscreteValues = 9
   VAnt_Config.Frequency:SetProperties(VAnt_tmp)
--

-- STEP 20: Mesh the project
   VAnt_Project.Mesher.Settings.WireRadius = 0.001
   VAnt_Project.Mesher.Settings.MeshSizeOption = cf.Enums.MeshSizeOptionEnum.Standard
   VAnt_Project.Mesher:Mesh()
--

-- STEP 21: Save project
   VSes_Application:SaveAs("C:/Users/project/0. My Work/1. Repositories/0. Unfriendly Train/Code/Templates/Tests/Lua/637049017619091072_0/0.cfx")
--

-- STEP 22: Run simulation
   VAnt_Project.Launcher.Settings.FEKO.Parallel.Enabled = true
   VAnt_Project.Launcher:RunFEKO()
--

-- STEP 23: Close project
   VSes_Application:CloseAllWindows()
--

-- STEP 1: Make a new project
   VAnt_Project    = VSes_Application:NewProject()
   VAnt_Geometry   = VAnt_Project.Geometry
--

-- STEP 2: Set project unit of measurement
   VAnt_Project.ModelUnit  = cf.Enums.ModelUnitEnum.Millimetres
--

-- STEP 3: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(82.28759, 53.578230000000005, 1.6)
   VTmp_Points[2] = cf.Point(82.28759, 55.178230000000006, 1.6)
   VTmp_Points[3] = cf.Point(88.68759, 55.178230000000006, 1.6)
   VTmp_Points[4] = cf.Point(88.68759, 53.578230000000005, 1.6)
   VAnt_Polygon_Feed_Top = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_Feed_Top.Label = "Feed_Top"
--

-- STEP 4: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(88.68759, 55.178230000000006, 1.6)
   VTmp_Points[2] = cf.Point(88.68759, 55.178230000000006, 0.8)
   VTmp_Points[3] = cf.Point(88.68759, 53.578230000000005, 0.8)
   VTmp_Points[4] = cf.Point(88.68759, 53.578230000000005, 1.6)
   VAnt_Polygon_Feed_Pos = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_Feed_Pos.Label = "Feed_Pos"
--

-- STEP 5: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(88.68759, 55.178230000000006, 0.0)
   VTmp_Points[2] = cf.Point(88.68759, 55.178230000000006, 0.8)
   VTmp_Points[3] = cf.Point(88.68759, 53.578230000000005, 0.8)
   VTmp_Points[4] = cf.Point(88.68759, 53.578230000000005, 0.0)
   VAnt_Polygon_Feed_Neg = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_Feed_Neg.Label = "Feed_Neg"
--

-- STEP 6: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(88.68759, 53.578230000000005, 0.0)
   VTmp_Points[2] = cf.Point(88.68759, 55.178230000000006, 0.0)
   VTmp_Points[3] = cf.Point(87.08759, 55.178230000000006, 0.0)
   VTmp_Points[4] = cf.Point(87.08759, 53.578230000000005, 0.0)
   VAnt_Polygon_Feed_Bot = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_Feed_Bot.Label = "Feed_Bot"
--

-- STEP 7: Create new rectangular surface
   VTmp_Corner = cf.Point(0.0, 0.0, 0.0)
   VAnt_Rectangle_GP = VAnt_Geometry:AddRectangle(VTmp_Corner, 87.08759, 108.75646)
   VAnt_Rectangle_GP.Label = "GP"
--

-- STEP 8: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(2.0, 2.0, 0.0)
   VTmp_Points[2] = cf.Point(4.0, 4.0, 0.0)
   VTmp_Points[3] = cf.Point(2.0, 4.0, 0.0)
   VAnt_Polygon_GPSlot_0 = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_GPSlot_0.Label = "GPSlot_0"
--

-- STEP 9: Create new subtraction
   VTmp_Subs = {}
   VTmp_Subs[1] = VAnt_Polygon_GPSlot_0
   VAnt_Subrtaction_GP_Slotted = VAnt_Geometry:Subtract(VAnt_Rectangle_GP, VTmp_Subs)
   VAnt_Subrtaction_GP_Slotted.Label = "GP_Slotted"
--

-- STEP 10: Creating medium
   VAnt_Medium_FR4 = VAnt_Project.Media:AddDielectric()
   VAnt_Medium_FR4.Label = "FR4"
   VAnt_Medium_FR4.DielectricModelling.RelativePermittivity = 4.4
   VAnt_Medium_FR4.DielectricModelling.LossTangent = 0.02
--

-- STEP 11: Create new solid.cuboid
   VTmp_Corner = cf.Point(0.0, 0.0, 0.0)
   VAnt_Cuboid_Substrate = VAnt_Geometry:AddCuboid(VTmp_Corner, 87.08759, 108.75646, 1.6)
   VAnt_Cuboid_Substrate.Label = "Substrate"
--

-- STEP 12: Set solid medium
   VAnt_Cuboid_Substrate.Regions:Item(1).Medium = VAnt_Project.Media:Item("FR4")
--

-- STEP 13: Create new rectangular surface
   VTmp_Corner = cf.Point(4.8, 4.8, 1.6)
   VAnt_Rectangle_RP = VAnt_Geometry:AddRectangle(VTmp_Corner, 77.48759, 99.15646)
   VAnt_Rectangle_RP.Label = "RP"
--

-- STEP 14: Create new union
   VTmp_Parts = {}
   VTmp_Parts[1] = VAnt_Subrtaction_GP_Slotted
   VTmp_Parts[2] = VAnt_Rectangle_RP
   VTmp_Parts[3] = VAnt_Cuboid_Substrate
   VTmp_Parts[4] = VAnt_Polygon_Feed_Top
   VTmp_Parts[5] = VAnt_Polygon_Feed_Pos
   VTmp_Parts[6] = VAnt_Polygon_Feed_Neg
   VTmp_Parts[7] = VAnt_Polygon_Feed_Bot
   VAnt_Union_Onion = VAnt_Geometry:Union(VTmp_Parts)
   VAnt_Union_Onion.Label = "Onion"
--

-- STEP 15: Changing face medium
   VAnt_Union_Onion.Faces:Item("Face14").Medium = VAnt_Project.Media:Item("Perfect electric conductor")
--

-- STEP 16: Changing face medium
   VAnt_Union_Onion.Faces:Item("Face15").Medium = VAnt_Project.Media:Item("Perfect electric conductor")
--

-- STEP 17: Changing face medium
   VAnt_Union_Onion.Faces:Item("Face16").Medium = VAnt_Project.Media:Item("Perfect electric conductor")
--

-- STEP 18: Create new edge port
   VTmp_Pos = {}
   VTmp_Neg = {}
   VTmp_Pos[1] = VAnt_Union_Onion.Faces:Item("Face2")
   VTmp_Neg[1] = VAnt_Union_Onion.Faces:Item("Face3")
   VAnt_EPort_SourcePort = VAnt_Project.Ports:AddEdgePort(VTmp_Pos, VTmp_Neg)
   VAnt_EPort_SourcePort.Label = "SourcePort"
--

-- STEP 19: Get config file
   VAnt_Config = VAnt_Project.SolutionConfigurations[1]
--

-- STEP 20: Create new voltage source
   VAnt_VSource_VoltageSource = VAnt_Config.Sources:AddVoltageSource(VAnt_EPort_SourcePort)
   VAnt_VSource_VoltageSource.Impedance = 50.0
   VAnt_VSource_VoltageSource.Magnitude = 1.0
   VAnt_VSource_VoltageSource.Phase = 0.0
   VAnt_VSource_VoltageSource.Label = "VoltageSource"
--

-- STEP 21: Set frequency range
   VAnt_tmp = VAnt_Config.Frequency:GetProperties()
   VAnt_tmp.Start  = 880000000.0
   VAnt_tmp.End    = 960000000.0
   VAnt_tmp.RangeType  = cf.Enums.FrequencyRangeTypeEnum.LinearSpacedDiscrete
   VAnt_tmp.NumberOfDiscreteValues = 9
   VAnt_Config.Frequency:SetProperties(VAnt_tmp)
--

-- STEP 22: Mesh the project
   VAnt_Project.Mesher.Settings.WireRadius = 0.001
   VAnt_Project.Mesher.Settings.MeshSizeOption = cf.Enums.MeshSizeOptionEnum.Standard
   VAnt_Project.Mesher:Mesh()
--

-- STEP 23: Save project
   VSes_Application:SaveAs("C:/Users/project/0. My Work/1. Repositories/0. Unfriendly Train/Code/Templates/Tests/Lua/637049017619091072_1/1.cfx")
--

-- STEP 24: Run simulation
   VAnt_Project.Launcher.Settings.FEKO.Parallel.Enabled = true
   VAnt_Project.Launcher:RunFEKO()
--

-- STEP 25: Close project
   VSes_Application:CloseAllWindows()
--

-- STEP 1: Make a new project
   VAnt_Project    = VSes_Application:NewProject()
   VAnt_Geometry   = VAnt_Project.Geometry
--

-- STEP 2: Set project unit of measurement
   VAnt_Project.ModelUnit  = cf.Enums.ModelUnitEnum.Millimetres
--

-- STEP 3: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(82.28759, 53.578230000000005, 1.6)
   VTmp_Points[2] = cf.Point(82.28759, 55.178230000000006, 1.6)
   VTmp_Points[3] = cf.Point(88.68759, 55.178230000000006, 1.6)
   VTmp_Points[4] = cf.Point(88.68759, 53.578230000000005, 1.6)
   VAnt_Polygon_Feed_Top = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_Feed_Top.Label = "Feed_Top"
--

-- STEP 4: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(88.68759, 55.178230000000006, 1.6)
   VTmp_Points[2] = cf.Point(88.68759, 55.178230000000006, 0.8)
   VTmp_Points[3] = cf.Point(88.68759, 53.578230000000005, 0.8)
   VTmp_Points[4] = cf.Point(88.68759, 53.578230000000005, 1.6)
   VAnt_Polygon_Feed_Pos = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_Feed_Pos.Label = "Feed_Pos"
--

-- STEP 5: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(88.68759, 55.178230000000006, 0.0)
   VTmp_Points[2] = cf.Point(88.68759, 55.178230000000006, 0.8)
   VTmp_Points[3] = cf.Point(88.68759, 53.578230000000005, 0.8)
   VTmp_Points[4] = cf.Point(88.68759, 53.578230000000005, 0.0)
   VAnt_Polygon_Feed_Neg = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_Feed_Neg.Label = "Feed_Neg"
--

-- STEP 6: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(88.68759, 53.578230000000005, 0.0)
   VTmp_Points[2] = cf.Point(88.68759, 55.178230000000006, 0.0)
   VTmp_Points[3] = cf.Point(87.08759, 55.178230000000006, 0.0)
   VTmp_Points[4] = cf.Point(87.08759, 53.578230000000005, 0.0)
   VAnt_Polygon_Feed_Bot = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_Feed_Bot.Label = "Feed_Bot"
--

-- STEP 7: Create new rectangular surface
   VTmp_Corner = cf.Point(0.0, 0.0, 0.0)
   VAnt_Rectangle_GP = VAnt_Geometry:AddRectangle(VTmp_Corner, 87.08759, 108.75646)
   VAnt_Rectangle_GP.Label = "GP"
--

-- STEP 8: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(2.0, 2.0, 0.0)
   VTmp_Points[2] = cf.Point(4.0, 4.0, 0.0)
   VTmp_Points[3] = cf.Point(2.0, 4.0, 0.0)
   VAnt_Polygon_GPSlot_0 = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_GPSlot_0.Label = "GPSlot_0"
--

-- STEP 9: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(12.0, 12.0, 0.0)
   VTmp_Points[2] = cf.Point(14.0, 14.0, 0.0)
   VTmp_Points[3] = cf.Point(12.0, 14.0, 0.0)
   VAnt_Polygon_GPSlot_1 = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_GPSlot_1.Label = "GPSlot_1"
--

-- STEP 10: Create new subtraction
   VTmp_Subs = {}
   VTmp_Subs[1] = VAnt_Polygon_GPSlot_0
   VTmp_Subs[2] = VAnt_Polygon_GPSlot_1
   VAnt_Subrtaction_GP_Slotted = VAnt_Geometry:Subtract(VAnt_Rectangle_GP, VTmp_Subs)
   VAnt_Subrtaction_GP_Slotted.Label = "GP_Slotted"
--

-- STEP 11: Creating medium
   VAnt_Medium_FR4 = VAnt_Project.Media:AddDielectric()
   VAnt_Medium_FR4.Label = "FR4"
   VAnt_Medium_FR4.DielectricModelling.RelativePermittivity = 4.4
   VAnt_Medium_FR4.DielectricModelling.LossTangent = 0.02
--

-- STEP 12: Create new solid.cuboid
   VTmp_Corner = cf.Point(0.0, 0.0, 0.0)
   VAnt_Cuboid_Substrate = VAnt_Geometry:AddCuboid(VTmp_Corner, 87.08759, 108.75646, 1.6)
   VAnt_Cuboid_Substrate.Label = "Substrate"
--

-- STEP 13: Set solid medium
   VAnt_Cuboid_Substrate.Regions:Item(1).Medium = VAnt_Project.Media:Item("FR4")
--

-- STEP 14: Create new rectangular surface
   VTmp_Corner = cf.Point(4.8, 4.8, 1.6)
   VAnt_Rectangle_RP = VAnt_Geometry:AddRectangle(VTmp_Corner, 77.48759, 99.15646)
   VAnt_Rectangle_RP.Label = "RP"
--

-- STEP 15: Create new union
   VTmp_Parts = {}
   VTmp_Parts[1] = VAnt_Subrtaction_GP_Slotted
   VTmp_Parts[2] = VAnt_Rectangle_RP
   VTmp_Parts[3] = VAnt_Cuboid_Substrate
   VTmp_Parts[4] = VAnt_Polygon_Feed_Top
   VTmp_Parts[5] = VAnt_Polygon_Feed_Pos
   VTmp_Parts[6] = VAnt_Polygon_Feed_Neg
   VTmp_Parts[7] = VAnt_Polygon_Feed_Bot
   VAnt_Union_Onion = VAnt_Geometry:Union(VTmp_Parts)
   VAnt_Union_Onion.Label = "Onion"
--

-- STEP 16: Changing face medium
   VAnt_Union_Onion.Faces:Item("Face15").Medium = VAnt_Project.Media:Item("Perfect electric conductor")
--

-- STEP 17: Changing face medium
   VAnt_Union_Onion.Faces:Item("Face16").Medium = VAnt_Project.Media:Item("Perfect electric conductor")
--

-- STEP 18: Changing face medium
   VAnt_Union_Onion.Faces:Item("Face17").Medium = VAnt_Project.Media:Item("Perfect electric conductor")
--

-- STEP 19: Create new edge port
   VTmp_Pos = {}
   VTmp_Neg = {}
   VTmp_Pos[1] = VAnt_Union_Onion.Faces:Item("Face2")
   VTmp_Neg[1] = VAnt_Union_Onion.Faces:Item("Face3")
   VAnt_EPort_SourcePort = VAnt_Project.Ports:AddEdgePort(VTmp_Pos, VTmp_Neg)
   VAnt_EPort_SourcePort.Label = "SourcePort"
--

-- STEP 20: Get config file
   VAnt_Config = VAnt_Project.SolutionConfigurations[1]
--

-- STEP 21: Create new voltage source
   VAnt_VSource_VoltageSource = VAnt_Config.Sources:AddVoltageSource(VAnt_EPort_SourcePort)
   VAnt_VSource_VoltageSource.Impedance = 50.0
   VAnt_VSource_VoltageSource.Magnitude = 1.0
   VAnt_VSource_VoltageSource.Phase = 0.0
   VAnt_VSource_VoltageSource.Label = "VoltageSource"
--

-- STEP 22: Set frequency range
   VAnt_tmp = VAnt_Config.Frequency:GetProperties()
   VAnt_tmp.Start  = 880000000.0
   VAnt_tmp.End    = 960000000.0
   VAnt_tmp.RangeType  = cf.Enums.FrequencyRangeTypeEnum.LinearSpacedDiscrete
   VAnt_tmp.NumberOfDiscreteValues = 9
   VAnt_Config.Frequency:SetProperties(VAnt_tmp)
--

-- STEP 23: Mesh the project
   VAnt_Project.Mesher.Settings.WireRadius = 0.001
   VAnt_Project.Mesher.Settings.MeshSizeOption = cf.Enums.MeshSizeOptionEnum.Standard
   VAnt_Project.Mesher:Mesh()
--

-- STEP 24: Save project
   VSes_Application:SaveAs("C:/Users/project/0. My Work/1. Repositories/0. Unfriendly Train/Code/Templates/Tests/Lua/637049017619091072_2/2.cfx")
--

-- STEP 25: Run simulation
   VAnt_Project.Launcher.Settings.FEKO.Parallel.Enabled = true
   VAnt_Project.Launcher:RunFEKO()
--

-- STEP 26: Close project
   VSes_Application:CloseAllWindows()
--

-- STEP 1: Make a new project
   VAnt_Project    = VSes_Application:NewProject()
   VAnt_Geometry   = VAnt_Project.Geometry
--

-- STEP 2: Set project unit of measurement
   VAnt_Project.ModelUnit  = cf.Enums.ModelUnitEnum.Millimetres
--

-- STEP 3: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(82.28759, 53.578230000000005, 1.6)
   VTmp_Points[2] = cf.Point(82.28759, 55.178230000000006, 1.6)
   VTmp_Points[3] = cf.Point(88.68759, 55.178230000000006, 1.6)
   VTmp_Points[4] = cf.Point(88.68759, 53.578230000000005, 1.6)
   VAnt_Polygon_Feed_Top = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_Feed_Top.Label = "Feed_Top"
--

-- STEP 4: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(88.68759, 55.178230000000006, 1.6)
   VTmp_Points[2] = cf.Point(88.68759, 55.178230000000006, 0.8)
   VTmp_Points[3] = cf.Point(88.68759, 53.578230000000005, 0.8)
   VTmp_Points[4] = cf.Point(88.68759, 53.578230000000005, 1.6)
   VAnt_Polygon_Feed_Pos = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_Feed_Pos.Label = "Feed_Pos"
--

-- STEP 5: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(88.68759, 55.178230000000006, 0.0)
   VTmp_Points[2] = cf.Point(88.68759, 55.178230000000006, 0.8)
   VTmp_Points[3] = cf.Point(88.68759, 53.578230000000005, 0.8)
   VTmp_Points[4] = cf.Point(88.68759, 53.578230000000005, 0.0)
   VAnt_Polygon_Feed_Neg = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_Feed_Neg.Label = "Feed_Neg"
--

-- STEP 6: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(88.68759, 53.578230000000005, 0.0)
   VTmp_Points[2] = cf.Point(88.68759, 55.178230000000006, 0.0)
   VTmp_Points[3] = cf.Point(87.08759, 55.178230000000006, 0.0)
   VTmp_Points[4] = cf.Point(87.08759, 53.578230000000005, 0.0)
   VAnt_Polygon_Feed_Bot = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_Feed_Bot.Label = "Feed_Bot"
--

-- STEP 7: Create new rectangular surface
   VTmp_Corner = cf.Point(0.0, 0.0, 0.0)
   VAnt_Rectangle_GP = VAnt_Geometry:AddRectangle(VTmp_Corner, 87.08759, 108.75646)
   VAnt_Rectangle_GP.Label = "GP"
--

-- STEP 8: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(2.0, 2.0, 0.0)
   VTmp_Points[2] = cf.Point(4.0, 4.0, 0.0)
   VTmp_Points[3] = cf.Point(2.0, 4.0, 0.0)
   VAnt_Polygon_GPSlot_0 = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_GPSlot_0.Label = "GPSlot_0"
--

-- STEP 9: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(12.0, 12.0, 0.0)
   VTmp_Points[2] = cf.Point(14.0, 14.0, 0.0)
   VTmp_Points[3] = cf.Point(12.0, 14.0, 0.0)
   VAnt_Polygon_GPSlot_1 = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_GPSlot_1.Label = "GPSlot_1"
--

-- STEP 10: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(22.0, 22.0, 0.0)
   VTmp_Points[2] = cf.Point(24.0, 24.0, 0.0)
   VTmp_Points[3] = cf.Point(22.0, 24.0, 0.0)
   VAnt_Polygon_GPSlot_2 = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_GPSlot_2.Label = "GPSlot_2"
--

-- STEP 11: Create new subtraction
   VTmp_Subs = {}
   VTmp_Subs[1] = VAnt_Polygon_GPSlot_0
   VTmp_Subs[2] = VAnt_Polygon_GPSlot_1
   VTmp_Subs[3] = VAnt_Polygon_GPSlot_2
   VAnt_Subrtaction_GP_Slotted = VAnt_Geometry:Subtract(VAnt_Rectangle_GP, VTmp_Subs)
   VAnt_Subrtaction_GP_Slotted.Label = "GP_Slotted"
--

-- STEP 12: Creating medium
   VAnt_Medium_FR4 = VAnt_Project.Media:AddDielectric()
   VAnt_Medium_FR4.Label = "FR4"
   VAnt_Medium_FR4.DielectricModelling.RelativePermittivity = 4.4
   VAnt_Medium_FR4.DielectricModelling.LossTangent = 0.02
--

-- STEP 13: Create new solid.cuboid
   VTmp_Corner = cf.Point(0.0, 0.0, 0.0)
   VAnt_Cuboid_Substrate = VAnt_Geometry:AddCuboid(VTmp_Corner, 87.08759, 108.75646, 1.6)
   VAnt_Cuboid_Substrate.Label = "Substrate"
--

-- STEP 14: Set solid medium
   VAnt_Cuboid_Substrate.Regions:Item(1).Medium = VAnt_Project.Media:Item("FR4")
--

-- STEP 15: Create new rectangular surface
   VTmp_Corner = cf.Point(4.8, 4.8, 1.6)
   VAnt_Rectangle_RP = VAnt_Geometry:AddRectangle(VTmp_Corner, 77.48759, 99.15646)
   VAnt_Rectangle_RP.Label = "RP"
--

-- STEP 16: Create new union
   VTmp_Parts = {}
   VTmp_Parts[1] = VAnt_Subrtaction_GP_Slotted
   VTmp_Parts[2] = VAnt_Rectangle_RP
   VTmp_Parts[3] = VAnt_Cuboid_Substrate
   VTmp_Parts[4] = VAnt_Polygon_Feed_Top
   VTmp_Parts[5] = VAnt_Polygon_Feed_Pos
   VTmp_Parts[6] = VAnt_Polygon_Feed_Neg
   VTmp_Parts[7] = VAnt_Polygon_Feed_Bot
   VAnt_Union_Onion = VAnt_Geometry:Union(VTmp_Parts)
   VAnt_Union_Onion.Label = "Onion"
--

-- STEP 17: Changing face medium
   VAnt_Union_Onion.Faces:Item("Face16").Medium = VAnt_Project.Media:Item("Perfect electric conductor")
--

-- STEP 18: Changing face medium
   VAnt_Union_Onion.Faces:Item("Face17").Medium = VAnt_Project.Media:Item("Perfect electric conductor")
--

-- STEP 19: Changing face medium
   VAnt_Union_Onion.Faces:Item("Face18").Medium = VAnt_Project.Media:Item("Perfect electric conductor")
--

-- STEP 20: Create new edge port
   VTmp_Pos = {}
   VTmp_Neg = {}
   VTmp_Pos[1] = VAnt_Union_Onion.Faces:Item("Face2")
   VTmp_Neg[1] = VAnt_Union_Onion.Faces:Item("Face3")
   VAnt_EPort_SourcePort = VAnt_Project.Ports:AddEdgePort(VTmp_Pos, VTmp_Neg)
   VAnt_EPort_SourcePort.Label = "SourcePort"
--

-- STEP 21: Get config file
   VAnt_Config = VAnt_Project.SolutionConfigurations[1]
--

-- STEP 22: Create new voltage source
   VAnt_VSource_VoltageSource = VAnt_Config.Sources:AddVoltageSource(VAnt_EPort_SourcePort)
   VAnt_VSource_VoltageSource.Impedance = 50.0
   VAnt_VSource_VoltageSource.Magnitude = 1.0
   VAnt_VSource_VoltageSource.Phase = 0.0
   VAnt_VSource_VoltageSource.Label = "VoltageSource"
--

-- STEP 23: Set frequency range
   VAnt_tmp = VAnt_Config.Frequency:GetProperties()
   VAnt_tmp.Start  = 880000000.0
   VAnt_tmp.End    = 960000000.0
   VAnt_tmp.RangeType  = cf.Enums.FrequencyRangeTypeEnum.LinearSpacedDiscrete
   VAnt_tmp.NumberOfDiscreteValues = 9
   VAnt_Config.Frequency:SetProperties(VAnt_tmp)
--

-- STEP 24: Mesh the project
   VAnt_Project.Mesher.Settings.WireRadius = 0.001
   VAnt_Project.Mesher.Settings.MeshSizeOption = cf.Enums.MeshSizeOptionEnum.Standard
   VAnt_Project.Mesher:Mesh()
--

-- STEP 25: Save project
   VSes_Application:SaveAs("C:/Users/project/0. My Work/1. Repositories/0. Unfriendly Train/Code/Templates/Tests/Lua/637049017619091072_3/3.cfx")
--

-- STEP 26: Run simulation
   VAnt_Project.Launcher.Settings.FEKO.Parallel.Enabled = true
   VAnt_Project.Launcher:RunFEKO()
--

-- STEP 27: Close project
   VSes_Application:CloseAllWindows()
--

-- STEP 1: Make a new project
   VAnt_Project    = VSes_Application:NewProject()
   VAnt_Geometry   = VAnt_Project.Geometry
--

-- STEP 2: Set project unit of measurement
   VAnt_Project.ModelUnit  = cf.Enums.ModelUnitEnum.Millimetres
--

-- STEP 3: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(82.28759, 53.578230000000005, 1.6)
   VTmp_Points[2] = cf.Point(82.28759, 55.178230000000006, 1.6)
   VTmp_Points[3] = cf.Point(88.68759, 55.178230000000006, 1.6)
   VTmp_Points[4] = cf.Point(88.68759, 53.578230000000005, 1.6)
   VAnt_Polygon_Feed_Top = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_Feed_Top.Label = "Feed_Top"
--

-- STEP 4: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(88.68759, 55.178230000000006, 1.6)
   VTmp_Points[2] = cf.Point(88.68759, 55.178230000000006, 0.8)
   VTmp_Points[3] = cf.Point(88.68759, 53.578230000000005, 0.8)
   VTmp_Points[4] = cf.Point(88.68759, 53.578230000000005, 1.6)
   VAnt_Polygon_Feed_Pos = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_Feed_Pos.Label = "Feed_Pos"
--

-- STEP 5: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(88.68759, 55.178230000000006, 0.0)
   VTmp_Points[2] = cf.Point(88.68759, 55.178230000000006, 0.8)
   VTmp_Points[3] = cf.Point(88.68759, 53.578230000000005, 0.8)
   VTmp_Points[4] = cf.Point(88.68759, 53.578230000000005, 0.0)
   VAnt_Polygon_Feed_Neg = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_Feed_Neg.Label = "Feed_Neg"
--

-- STEP 6: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(88.68759, 53.578230000000005, 0.0)
   VTmp_Points[2] = cf.Point(88.68759, 55.178230000000006, 0.0)
   VTmp_Points[3] = cf.Point(87.08759, 55.178230000000006, 0.0)
   VTmp_Points[4] = cf.Point(87.08759, 53.578230000000005, 0.0)
   VAnt_Polygon_Feed_Bot = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_Feed_Bot.Label = "Feed_Bot"
--

-- STEP 7: Create new rectangular surface
   VTmp_Corner = cf.Point(0.0, 0.0, 0.0)
   VAnt_Rectangle_GP = VAnt_Geometry:AddRectangle(VTmp_Corner, 87.08759, 108.75646)
   VAnt_Rectangle_GP.Label = "GP"
--

-- STEP 8: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(2.0, 2.0, 0.0)
   VTmp_Points[2] = cf.Point(4.0, 4.0, 0.0)
   VTmp_Points[3] = cf.Point(2.0, 4.0, 0.0)
   VAnt_Polygon_GPSlot_0 = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_GPSlot_0.Label = "GPSlot_0"
--

-- STEP 9: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(12.0, 12.0, 0.0)
   VTmp_Points[2] = cf.Point(14.0, 14.0, 0.0)
   VTmp_Points[3] = cf.Point(12.0, 14.0, 0.0)
   VAnt_Polygon_GPSlot_1 = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_GPSlot_1.Label = "GPSlot_1"
--

-- STEP 10: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(22.0, 22.0, 0.0)
   VTmp_Points[2] = cf.Point(24.0, 24.0, 0.0)
   VTmp_Points[3] = cf.Point(22.0, 24.0, 0.0)
   VAnt_Polygon_GPSlot_2 = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_GPSlot_2.Label = "GPSlot_2"
--

-- STEP 11: Create new subtraction
   VTmp_Subs = {}
   VTmp_Subs[1] = VAnt_Polygon_GPSlot_0
   VTmp_Subs[2] = VAnt_Polygon_GPSlot_1
   VTmp_Subs[3] = VAnt_Polygon_GPSlot_2
   VAnt_Subrtaction_GP_Slotted = VAnt_Geometry:Subtract(VAnt_Rectangle_GP, VTmp_Subs)
   VAnt_Subrtaction_GP_Slotted.Label = "GP_Slotted"
--

-- STEP 12: Creating medium
   VAnt_Medium_FR4 = VAnt_Project.Media:AddDielectric()
   VAnt_Medium_FR4.Label = "FR4"
   VAnt_Medium_FR4.DielectricModelling.RelativePermittivity = 4.4
   VAnt_Medium_FR4.DielectricModelling.LossTangent = 0.02
--

-- STEP 13: Create new solid.cuboid
   VTmp_Corner = cf.Point(0.0, 0.0, 0.0)
   VAnt_Cuboid_Substrate = VAnt_Geometry:AddCuboid(VTmp_Corner, 87.08759, 108.75646, 1.6)
   VAnt_Cuboid_Substrate.Label = "Substrate"
--

-- STEP 14: Set solid medium
   VAnt_Cuboid_Substrate.Regions:Item(1).Medium = VAnt_Project.Media:Item("FR4")
--

-- STEP 15: Create new rectangular surface
   VTmp_Corner = cf.Point(4.8, 4.8, 1.6)
   VAnt_Rectangle_RP = VAnt_Geometry:AddRectangle(VTmp_Corner, 77.48759, 99.15646)
   VAnt_Rectangle_RP.Label = "RP"
--

-- STEP 16: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(2.0, 2.0, 1.6)
   VTmp_Points[2] = cf.Point(4.0, 4.0, 1.6)
   VTmp_Points[3] = cf.Point(2.0, 4.0, 1.6)
   VAnt_Polygon_RPSlot_0 = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_RPSlot_0.Label = "RPSlot_0"
--

-- STEP 17: Create new subtraction
   VTmp_Subs = {}
   VTmp_Subs[1] = VAnt_Polygon_RPSlot_0
   VAnt_Subrtaction_RP_Slotted = VAnt_Geometry:Subtract(VAnt_Rectangle_RP, VTmp_Subs)
   VAnt_Subrtaction_RP_Slotted.Label = "RP_Slotted"
--

-- STEP 18: Create new union
   VTmp_Parts = {}
   VTmp_Parts[1] = VAnt_Subrtaction_GP_Slotted
   VTmp_Parts[2] = VAnt_Subrtaction_RP_Slotted
   VTmp_Parts[3] = VAnt_Cuboid_Substrate
   VTmp_Parts[4] = VAnt_Polygon_Feed_Top
   VTmp_Parts[5] = VAnt_Polygon_Feed_Pos
   VTmp_Parts[6] = VAnt_Polygon_Feed_Neg
   VTmp_Parts[7] = VAnt_Polygon_Feed_Bot
   VAnt_Union_Onion = VAnt_Geometry:Union(VTmp_Parts)
   VAnt_Union_Onion.Label = "Onion"
--

-- STEP 19: Changing face medium
   VAnt_Union_Onion.Faces:Item("Face17").Medium = VAnt_Project.Media:Item("Perfect electric conductor")
--

-- STEP 20: Changing face medium
   VAnt_Union_Onion.Faces:Item("Face18").Medium = VAnt_Project.Media:Item("Perfect electric conductor")
--

-- STEP 21: Changing face medium
   VAnt_Union_Onion.Faces:Item("Face19").Medium = VAnt_Project.Media:Item("Perfect electric conductor")
--

-- STEP 22: Create new edge port
   VTmp_Pos = {}
   VTmp_Neg = {}
   VTmp_Pos[1] = VAnt_Union_Onion.Faces:Item("Face2")
   VTmp_Neg[1] = VAnt_Union_Onion.Faces:Item("Face3")
   VAnt_EPort_SourcePort = VAnt_Project.Ports:AddEdgePort(VTmp_Pos, VTmp_Neg)
   VAnt_EPort_SourcePort.Label = "SourcePort"
--

-- STEP 23: Get config file
   VAnt_Config = VAnt_Project.SolutionConfigurations[1]
--

-- STEP 24: Create new voltage source
   VAnt_VSource_VoltageSource = VAnt_Config.Sources:AddVoltageSource(VAnt_EPort_SourcePort)
   VAnt_VSource_VoltageSource.Impedance = 50.0
   VAnt_VSource_VoltageSource.Magnitude = 1.0
   VAnt_VSource_VoltageSource.Phase = 0.0
   VAnt_VSource_VoltageSource.Label = "VoltageSource"
--

-- STEP 25: Set frequency range
   VAnt_tmp = VAnt_Config.Frequency:GetProperties()
   VAnt_tmp.Start  = 880000000.0
   VAnt_tmp.End    = 960000000.0
   VAnt_tmp.RangeType  = cf.Enums.FrequencyRangeTypeEnum.LinearSpacedDiscrete
   VAnt_tmp.NumberOfDiscreteValues = 9
   VAnt_Config.Frequency:SetProperties(VAnt_tmp)
--

-- STEP 26: Mesh the project
   VAnt_Project.Mesher.Settings.WireRadius = 0.001
   VAnt_Project.Mesher.Settings.MeshSizeOption = cf.Enums.MeshSizeOptionEnum.Standard
   VAnt_Project.Mesher:Mesh()
--

-- STEP 27: Save project
   VSes_Application:SaveAs("C:/Users/project/0. My Work/1. Repositories/0. Unfriendly Train/Code/Templates/Tests/Lua/637049017619091072_4/4.cfx")
--

-- STEP 28: Run simulation
   VAnt_Project.Launcher.Settings.FEKO.Parallel.Enabled = true
   VAnt_Project.Launcher:RunFEKO()
--

-- STEP 29: Close project
   VSes_Application:CloseAllWindows()
--

-- STEP ??: Close file
   VSes_Application:CloseAllWindows()
   VSes_Application:Close()
--
