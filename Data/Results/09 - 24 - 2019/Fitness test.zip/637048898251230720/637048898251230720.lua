--   STEP 0: Get application
   VSes_Application = cf.GetApplication()
--

-- STEP 1: Make a new project
   VAnt_Project    = VSes_Application:NewProject()
   VAnt_Geometry   = VAnt_Project.Geometry
--

-- STEP 2: Set project unit of measurement
   VAnt_Project.ModelUnit  = cf.Enums.ModelUnitEnum.Millimetres
--

-- STEP 3: Create new rectangular surface
   VTmp_Corner = cf.Point(0.0, 0.0, 0.0)
   VAnt_Rectangle_GroundPlane = VAnt_Geometry:AddRectangle(VTmp_Corner, 87.08759, 108.75646)
   VAnt_Rectangle_GroundPlane.Label = "GroundPlane"
--

-- STEP 4: Create new rectangular surface
   VTmp_Corner = cf.Point(4.8, 4.8, 1.6)
   VAnt_Rectangle_RadiatingPlane = VAnt_Geometry:AddRectangle(VTmp_Corner, 77.48759, 99.15646)
   VAnt_Rectangle_RadiatingPlane.Label = "RadiatingPlane"
--

-- STEP 5: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(82.28759, 53.578230000000005, 1.6)
   VTmp_Points[2] = cf.Point(82.28759, 55.17823, 1.6)
   VTmp_Points[3] = cf.Point(88.68759, 55.17823, 1.6)
   VTmp_Points[4] = cf.Point(88.68759, 53.578230000000005, 1.6)
   VAnt_Polygon_TopFeedStrip = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_TopFeedStrip.Label = "TopFeedStrip"
--

-- STEP 6: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(88.68759, 55.17823, 1.6)
   VTmp_Points[2] = cf.Point(88.68759, 53.578230000000005, 1.6)
   VTmp_Points[3] = cf.Point(88.68759, 53.578230000000005, 0.8)
   VTmp_Points[4] = cf.Point(88.68759, 55.17823, 0.8)
   VAnt_Polygon_TopFeedConnect = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_TopFeedConnect.Label = "TopFeedConnect"
--

-- STEP 7: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(88.68759, 55.17823, 0.0)
   VTmp_Points[2] = cf.Point(88.68759, 53.578230000000005, 0.0)
   VTmp_Points[3] = cf.Point(88.68759, 53.578230000000005, 0.8)
   VTmp_Points[4] = cf.Point(88.68759, 55.17823, 0.8)
   VAnt_Polygon_BotFeedConnect = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_BotFeedConnect.Label = "BotFeedConnect"
--

-- STEP 8: Create new polygonal surface
   VTmp_Points = {}
   VTmp_Points[1] = cf.Point(88.68759, 55.17823, 0.0)
   VTmp_Points[2] = cf.Point(88.68759, 53.578230000000005, 0.0)
   VTmp_Points[3] = cf.Point(87.08759, 53.578230000000005, 0.0)
   VTmp_Points[4] = cf.Point(87.08759, 55.17823, 0.0)
   VAnt_Polygon_BotFeedStrip = VAnt_Geometry:AddPolygon(VTmp_Points)
   VAnt_Polygon_BotFeedStrip.Label = "BotFeedStrip"
--

-- STEP 9: Creating medium
   VAnt_Medium_FR4 = VAnt_Project.Media:AddDielectric()
   VAnt_Medium_FR4.Label = "FR4"
   VAnt_Medium_FR4.DielectricModelling.RelativePermittivity = 4.4
   VAnt_Medium_FR4.DielectricModelling.LossTangent = 0.02
--

-- STEP 10: Create new solid.cuboid
   VTmp_Corner = cf.Point(0.0, 0.0, 0.0)
   VAnt_Cuboid_Substrate = VAnt_Geometry:AddCuboid(VTmp_Corner, 87.08759, 108.75646, 1.6)
   VAnt_Cuboid_Substrate.Label = "Substrate"
--

-- STEP 11: Set solid medium
   VAnt_Cuboid_Substrate.Regions:Item(1).Medium = VAnt_Project.Media:Item("FR4")
--

-- STEP 12: Create new union
   VTmp_Parts = {}
   VTmp_Parts[1] = VAnt_Rectangle_GroundPlane
   VTmp_Parts[2] = VAnt_Rectangle_RadiatingPlane
   VTmp_Parts[3] = VAnt_Polygon_TopFeedStrip
   VTmp_Parts[4] = VAnt_Polygon_TopFeedConnect
   VTmp_Parts[5] = VAnt_Polygon_BotFeedConnect
   VTmp_Parts[6] = VAnt_Polygon_BotFeedStrip
   VTmp_Parts[7] = VAnt_Cuboid_Substrate
   VAnt_Union_Union = VAnt_Geometry:Union(VTmp_Parts)
   VAnt_Union_Union.Label = "Union"
--

-- STEP 13: Changing face medium
   VAnt_Union_Union.Faces:Item("Face13").Medium = VAnt_Project.Media:Item("Perfect electric conductor")
--

-- STEP 14: Changing face medium
   VAnt_Union_Union.Faces:Item("Face14").Medium = VAnt_Project.Media:Item("Perfect electric conductor")
--

-- STEP 15: Changing face medium
   VAnt_Union_Union.Faces:Item("Face15").Medium = VAnt_Project.Media:Item("Perfect electric conductor")
--

-- STEP 16: Create new edge port
   VTmp_Pos = {}
   VTmp_Neg = {}
   VTmp_Pos[1] = VAnt_Union_Union.Faces:Item("Face4")
   VTmp_Neg[1] = VAnt_Union_Union.Faces:Item("Face5")
   VAnt_EPort_EdgePort = VAnt_Project.Ports:AddEdgePort(VTmp_Pos, VTmp_Neg)
   VAnt_EPort_EdgePort.Label = "EdgePort"
--

-- STEP 17: Get config file
   VAnt_Config = VAnt_Project.SolutionConfigurations[1]
--

-- STEP 18: Create new voltage source
   VAnt_VSource_VSource = VAnt_Config.Sources:AddVoltageSource(VAnt_EPort_EdgePort)
   VAnt_VSource_VSource.Impedance = 50.0
   VAnt_VSource_VSource.Magnitude = 1.0
   VAnt_VSource_VSource.Phase = 0.0
   VAnt_VSource_VSource.Label = "VSource"
--

-- STEP 19: Set frequency range
   VAnt_tmp = VAnt_Config.Frequency:GetProperties()
   VAnt_tmp.Start  = 890000000.0
   VAnt_tmp.End    = 950000000.0
   VAnt_tmp.RangeType  = cf.Enums.FrequencyRangeTypeEnum.LinearSpacedDiscrete
   VAnt_tmp.NumberOfDiscreteValues = 36
   VAnt_Config.Frequency:SetProperties(VAnt_tmp)
--

-- STEP 20: Mesh the project
   VAnt_Project.Mesher.Settings.WireRadius = 0.001
   VAnt_Project.Mesher.Settings.MeshSizeOption = cf.Enums.MeshSizeOptionEnum.Fine
   VAnt_Project.Mesher:Mesh()
--

-- STEP 21: Save project
   VSes_Application:SaveAs("C:/Users/project/0. My Work/1. Repositories/0. Unfriendly Train/Code/Templates/Tests/Lua/637048898251230720_StartPoint/StartPoint.cfx")
--

-- STEP 22: Run simulation
   VAnt_Project.Launcher.Settings.FEKO.Parallel.Enabled = true
   VAnt_Project.Launcher:RunFEKO()
--

-- STEP 23: Close project
   VSes_Application:CloseAllWindows()
--

-- STEP ??: Close file
   VSes_Application:CloseAllWindows()
   VSes_Application:Close()
--
